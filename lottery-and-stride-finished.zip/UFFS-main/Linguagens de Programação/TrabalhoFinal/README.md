# Base para implementação do Lambda Cálculo em Haskell

# Exemplo de execução

```console
$ runghc Main.hs < example1.hs 
$ runghc Main.hs < example2.hs
```

Multiplicação (DONE)
Or (DONE)
Maior (DONE)
Maior ou igual (DONE)
Subtração (DONE)
Not (DONE)
Pares (DONE)
LET 

types and programming languages pdf github
