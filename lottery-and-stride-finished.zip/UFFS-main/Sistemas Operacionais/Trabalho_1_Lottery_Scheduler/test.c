#include "types.h"
#include "user.h"

#define CHILDS 10				// Quantidade de filhos que vão ser criados
#define QUANTUM 112345678		// 10^8 = Time of thread execution


// Execution time of process:
void quantumLoop(){
	int i;
	i = QUANTUM;
	while(i--){
	}
	i = QUANTUM;
	while(i--){
	}
}

// Instanciation of multiple process to test:
int main(){
	int pid;
	int i;
	int testValues[CHILDS] = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90};

	for(i = 0; i < CHILDS; i++){
		pid= fork(testValues[i]);
        cps();
        printf(1,"\n" );

		if(pid == 0){
        	quantumLoop();
    		exit();
		}
	}

	// Waits for process end and print his informations:
	for(;;){
        pid = wait();
     	if(pid<0)break;
     	printf(1,"Child %d finished\n",pid );
	}
	exit();
}
